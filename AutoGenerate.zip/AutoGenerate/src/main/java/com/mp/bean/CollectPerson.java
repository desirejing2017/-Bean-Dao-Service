package com.mp.bean;

import java.sql.Timestamp;

public class CollectPerson{

	private	String	number;
	private	String	phone;
	private	String	name;
	private	Integer	type;
	private	String	location;
	private	String	cause;
	private	String	id;
	private	Timestamp	createTime;
	private	Integer	result;
	private	Byte	monitor;
	private	String	monitorId;
	private	Byte	readStatus;
	private	String	xp;
	private	String	sfzh;
	private	String	xb;
	private	String	mz;
	private	String	address;
	public	String	getNumber(){
		return	number;
	}
	public	String	getPhone(){
		return	phone;
	}
	public	String	getName(){
		return	name;
	}
	public	Integer	getType(){
		return	type;
	}
	public	String	getLocation(){
		return	location;
	}
	public	String	getCause(){
		return	cause;
	}
	public	String	getId(){
		return	id;
	}
	public	Timestamp	getCreateTime(){
		return	createTime;
	}
	public	Integer	getResult(){
		return	result;
	}
	public	Byte	getMonitor(){
		return	monitor;
	}
	public	String	getMonitorId(){
		return	monitorId;
	}
	public	Byte	getReadStatus(){
		return	readStatus;
	}
	public	String	getXp(){
		return	xp;
	}
	public	String	getSfzh(){
		return	sfzh;
	}
	public	String	getXb(){
		return	xb;
	}
	public	String	getMz(){
		return	mz;
	}
	public	String	getAddress(){
		return	address;
	}
	public void	setNumber(String number){
		this.number = number;
	}
	public void	setPhone(String phone){
		this.phone = phone;
	}
	public void	setName(String name){
		this.name = name;
	}
	public void	setType(Integer type){
		this.type = type;
	}
	public void	setLocation(String location){
		this.location = location;
	}
	public void	setCause(String cause){
		this.cause = cause;
	}
	public void	setId(String id){
		this.id = id;
	}
	public void	setCreateTime(Timestamp createTime){
		this.createTime = createTime;
	}
	public void	setResult(Integer result){
		this.result = result;
	}
	public void	setMonitor(Byte monitor){
		this.monitor = monitor;
	}
	public void	setMonitorId(String monitorId){
		this.monitorId = monitorId;
	}
	public void	setReadStatus(Byte readStatus){
		this.readStatus = readStatus;
	}
	public void	setXp(String xp){
		this.xp = xp;
	}
	public void	setSfzh(String sfzh){
		this.sfzh = sfzh;
	}
	public void	setXb(String xb){
		this.xb = xb;
	}
	public void	setMz(String mz){
		this.mz = mz;
	}
	public void	setAddress(String address){
		this.address = address;
	}
	public	CollectPerson(){
		super();
	}
	public CollectPerson(String number,String phone,String name,Integer type,String location,String cause,String id,Timestamp createTime,Integer result,Byte monitor,String monitorId,Byte readStatus,String xp,String sfzh,String xb,String mz,String address){
		super();
		this.number = number;
		this.phone = phone;
		this.name = name;
		this.type = type;
		this.location = location;
		this.cause = cause;
		this.id = id;
		this.createTime = createTime;
		this.result = result;
		this.monitor = monitor;
		this.monitorId = monitorId;
		this.readStatus = readStatus;
		this.xp = xp;
		this.sfzh = sfzh;
		this.xb = xb;
		this.mz = mz;
		this.address = address;
	}
}