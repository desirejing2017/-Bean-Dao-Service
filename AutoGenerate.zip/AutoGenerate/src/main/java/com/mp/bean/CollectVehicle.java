package com.mp.bean;

import java.util.Date;

import java.sql.Timestamp;

public class CollectVehicle{

	private	String	id;
	private	String	cph;
	private	String	cx;
	private	String	ys;
	private	String	xm;
	private	String	xb;
	private	String	mz;
	private	String	sfzh;
	private	String	dz;
	private	String	czdh;
	private	String	hcdz;
	private	String	hcyy;
	private	String	hcjg;
	private	Date	lasj;
	private	String	ladw;
	private	Byte	monitor;
	private	String	monitorId;
	private	Byte	readStatus;
	private	Timestamp	createTime;
	private	String	xp;
	public	String	getId(){
		return	id;
	}
	public	String	getCph(){
		return	cph;
	}
	public	String	getCx(){
		return	cx;
	}
	public	String	getYs(){
		return	ys;
	}
	public	String	getXm(){
		return	xm;
	}
	public	String	getXb(){
		return	xb;
	}
	public	String	getMz(){
		return	mz;
	}
	public	String	getSfzh(){
		return	sfzh;
	}
	public	String	getDz(){
		return	dz;
	}
	public	String	getCzdh(){
		return	czdh;
	}
	public	String	getHcdz(){
		return	hcdz;
	}
	public	String	getHcyy(){
		return	hcyy;
	}
	public	String	getHcjg(){
		return	hcjg;
	}
	public	Date	getLasj(){
		return	lasj;
	}
	public	String	getLadw(){
		return	ladw;
	}
	public	Byte	getMonitor(){
		return	monitor;
	}
	public	String	getMonitorId(){
		return	monitorId;
	}
	public	Byte	getReadStatus(){
		return	readStatus;
	}
	public	Timestamp	getCreateTime(){
		return	createTime;
	}
	public	String	getXp(){
		return	xp;
	}
	public void	setId(String id){
		this.id = id;
	}
	public void	setCph(String cph){
		this.cph = cph;
	}
	public void	setCx(String cx){
		this.cx = cx;
	}
	public void	setYs(String ys){
		this.ys = ys;
	}
	public void	setXm(String xm){
		this.xm = xm;
	}
	public void	setXb(String xb){
		this.xb = xb;
	}
	public void	setMz(String mz){
		this.mz = mz;
	}
	public void	setSfzh(String sfzh){
		this.sfzh = sfzh;
	}
	public void	setDz(String dz){
		this.dz = dz;
	}
	public void	setCzdh(String czdh){
		this.czdh = czdh;
	}
	public void	setHcdz(String hcdz){
		this.hcdz = hcdz;
	}
	public void	setHcyy(String hcyy){
		this.hcyy = hcyy;
	}
	public void	setHcjg(String hcjg){
		this.hcjg = hcjg;
	}
	public void	setLasj(Date lasj){
		this.lasj = lasj;
	}
	public void	setLadw(String ladw){
		this.ladw = ladw;
	}
	public void	setMonitor(Byte monitor){
		this.monitor = monitor;
	}
	public void	setMonitorId(String monitorId){
		this.monitorId = monitorId;
	}
	public void	setReadStatus(Byte readStatus){
		this.readStatus = readStatus;
	}
	public void	setCreateTime(Timestamp createTime){
		this.createTime = createTime;
	}
	public void	setXp(String xp){
		this.xp = xp;
	}
	public	CollectVehicle(){
		super();
	}
	public CollectVehicle(String id,String cph,String cx,String ys,String xm,String xb,String mz,String sfzh,String dz,String czdh,String hcdz,String hcyy,String hcjg,Date lasj,String ladw,Byte monitor,String monitorId,Byte readStatus,Timestamp createTime,String xp){
		super();
		this.id = id;
		this.cph = cph;
		this.cx = cx;
		this.ys = ys;
		this.xm = xm;
		this.xb = xb;
		this.mz = mz;
		this.sfzh = sfzh;
		this.dz = dz;
		this.czdh = czdh;
		this.hcdz = hcdz;
		this.hcyy = hcyy;
		this.hcjg = hcjg;
		this.lasj = lasj;
		this.ladw = ladw;
		this.monitor = monitor;
		this.monitorId = monitorId;
		this.readStatus = readStatus;
		this.createTime = createTime;
		this.xp = xp;
	}
}