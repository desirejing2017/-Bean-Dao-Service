package auto.bean;

import java.util.List;

/**
* ���ݱ��ı��ṹ
* @author 
*
*/
public class TableStruct {
	private String tableName;//����
	private List Columns;//���е���
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public List getColumns() {
		return Columns;
	}
	public void setColumns(List columns) {
		Columns = columns;
	}
	public TableStruct(String tableName, List columns) {
		super();
		this.tableName = tableName;
		Columns = columns;
	}
	public TableStruct() {
		super();
	}
	@Override
	public String toString() {
		return "TableStruct [tableName=" + tableName + ", Columns=" + Columns
		+ "]";
	}
}
